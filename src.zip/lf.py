import json
import asyncio
import time
import os, sys
from io import TextIOWrapper, BytesIO

SUCCESS=0
_stdout = sys.stdout
_stderr = sys.stderr


print(123)