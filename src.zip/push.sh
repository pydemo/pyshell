git pull
git add --all .
git commit -m new
git push

