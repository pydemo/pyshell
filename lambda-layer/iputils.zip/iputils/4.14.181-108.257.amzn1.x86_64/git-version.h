#define PACKAGE_VERSION "s20200821-3-g86ed089"
#define IPUTILS_VERSION(_prog) "%s from %s %s\n", _prog, PACKAGE_NAME, PACKAGE_VERSION
