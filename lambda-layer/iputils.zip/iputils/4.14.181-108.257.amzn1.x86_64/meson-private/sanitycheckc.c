int main(int argc, char **argv) { int class=0; return class; }
